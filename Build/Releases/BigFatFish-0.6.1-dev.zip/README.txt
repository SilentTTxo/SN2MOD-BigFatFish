﻿Big Fat Fish 0.6.1-dev

依赖 / Requirement: UE4SS
https://www.nexusmods.com/subnautica2/mods/36

安装：
1. 完全退出游戏。
2. 将本压缩包中的 Subnautica2 文件夹合并到 Steam“浏览本地文件”打开的游戏根目录；更新时覆盖本模组同名文件。
3. 启动游戏并载入存档，等待几秒。打开游戏控制台后输入：
   bigfatfish_spawn 3
   bigfatfish_follow

Installation:
1. Fully exit the game.
2. Merge this archive's Subnautica2 folder into the game root opened through Steam > Browse local files. Replace this mod's matching files when updating.
3. Start the game, load a save, and wait a few seconds. Open the in-game console and enter:
   bigfatfish_spawn 3
   bigfatfish_follow

通过游戏自身的保存功能保存；模组自动创建数据目录，每个世界保留一个 JSON 和一个 .bak。
Save using the game's own save function. The mod creates its data folder automatically and keeps one JSON and one .bak per world.

完整命令、借物表和说明见 / Full commands, credits and documentation:
BigFatFish_User_Guide_EN_ZH.md

模型 / Model: 木子恶魔 / MZEM —《蓝色小肥鱼 Deepseek 鲸鱼娘 VRM》
游泳动作 / Swim: Quaternius Universal Animation Library, Swim_Fwd_Loop (CC0)
JSON: rxi/json.lua (MIT); license included in Scripts/json.LICENSE.
